



def clear_genre():
    w.clearProperty(GENRE_FILTER_PROP)
