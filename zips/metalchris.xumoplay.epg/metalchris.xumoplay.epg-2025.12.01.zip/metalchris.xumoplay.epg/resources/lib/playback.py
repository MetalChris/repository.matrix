import xbmc
import xbmcgui

ICON = 'special://home/addons/metalchris.xumoplay.epg/resources/media/icon.png'

def play_episode(ep, epg_window=None):
    """
    Play a video stream directly without using InputStream Adaptive.
    """
    try:
        title = ep.get("episode_title") or ep.get("title") or "Unknown"
        desc  = ep.get("episode_description") or ep.get("description") or ""
        url   = ep.get("content", {}).get("url")
        image = ep.get("img_thumbh")

        if not url:
            xbmcgui.Dialog().notification(
                heading = "XumoPlay EPG",
                message = "No stream URL",
                icon = ICON,
                time = 3000,
                sound=False
            )
            return

        # Create ListItem
        li = xbmcgui.ListItem(label=title)
        if image:
            li.setArt({'icon': image, 'thumb': image})
        li.setInfo("video", {"title": title, "plot": desc})
        li.setProperty("IsPlayable", "true")

        # Close the EPG window if one was passed
        #if epg_window:
            #try:
                #epg_window.close()
            #except Exception:
                #pass

        log(f"[PLAYBACK] Playing directly: {title} ({url})", xbmc.LOGINFO)
        xbmc.Player().play(item=url, listitem=li)

    except Exception as e:
        log(f"[PLAYBACK] play_episode failed: {e}", xbmc.LOGERROR)
