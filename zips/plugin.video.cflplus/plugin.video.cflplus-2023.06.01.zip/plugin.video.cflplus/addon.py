#!/usr/bin/python
#
#
# Written by MetalChris 06.24.2023
# Released under GPL(v2 or later)

from six.moves import urllib_parse, urllib_request, urllib_error, http_client
from kodi_six import xbmc, xbmcplugin, xbmcaddon, xbmcgui, xbmcvfs
import OpenSSL, urllib, re, sys, os
from bs4 import BeautifulSoup
import html5lib
import mechanize
import json
import requests

if sys.version_info >= (3, 4, 0):
	import html
	_html_parser = html
	PY2 = False
	translatePath = xbmcvfs.translatePath
else:
	from six.moves import html_parser
	_html_parser = html_parser.HTMLParser()
	PY2 = True
	translatePath = xbmc.translatePath

artbase = 'special://home/addons/plugin.video.cflplus/resources/media/'
_addon = xbmcaddon.Addon()
_addon_path = _addon.getAddonInfo('path')
selfAddon = xbmcaddon.Addon(id='plugin.video.cflplus')
translation = selfAddon.getLocalizedString
usexbmc = selfAddon.getSetting('watchinxbmc')
settings = xbmcaddon.Addon(id="plugin.video.cflplus")
addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')
__resource__   = xbmcvfs.translatePath( os.path.join( _addon_path, 'resources', 'lib'))#.encode("utf-8") ).decode("utf-8")

sys.path.append(__resource__)

from uas import *

log_notice = settings.getSetting(id="log_notice")
if log_notice != 'false':
	log_level = xbmc.LOGNOTICE if PY2 else xbmc.LOGINFO
else:
	log_level = xbmc.LOGDEBUG
xbmc.log('LOG_NOTICE: ' + str(log_notice), level=log_level)

plugin = "CFL Video"

defaultimage = 'special://home/addons/plugin.video.cflplus/icon.png'
defaultfanart = 'special://home/addons/plugin.video.cflplus/resources/media/fanart.jpg'
defaulticon = 'special://home/addons/plugin.video.cflplus/icon.png'
#fanart = 'special://home/addons/plugin.video.cflplus/media/FBCL-20120713121328.jpg'
#cflfanart = 'special://home/addons/plugin.video.cflplus/resources/media/FBCL-20120713121328.jpg'
pubId = '4401740954001'

local_string = xbmcaddon.Addon(id='plugin.video.cflplus').getLocalizedString
pluginhandle = int(sys.argv[1])
confluence_views = [500,501,502,503,504,508,515]
baseurl = 'https://www.cfl.ca/plus/'

br = mechanize.Browser()
br.addheaders = [('Host', 'www.cfl.ca')]
br.addheaders = [('User-agent', ua)]
br.addheaders = [('Accept', 'application/json;pk=BCpkADawqM0dhxjC63Ux5MXyiMyIYB1S1bvk0iorISSaD1jFgWDyiv-JAcvE6XduNdDYxMdk_NTQWn91IQI9NLPkXd5UIw3cv49pcyJ5eW9QT0CWTrclSFHBHqSSyJ_9Ysgzc2v-Mw0wxNmZ')]
xbmc.log('UA: ' + str(ua))


def cfl(baseurl):
	br.set_handle_robots( False )
	response = br.open('https://www.cfl.ca/plus/')
	xbmc.log(str(response.code), level=log_level)
	html = response.get_data()
	soup = BeautifulSoup(html, 'html.parser')#.find("division",{"class":"item-title"})#[0]
	#xbmc.log('SOUP: ' + str(soup), level=log_level)
	for anchor in soup.find_all("div",{"class":"grid-col-6 section-item"}):
		title = anchor.find("div",{"class":"item-title"}).text.strip()
		xbmc.log('TITLE: ' + str(title), level=log_level)
		plot = anchor.find("div",{"class":"item-description"}).text.strip()
		xbmc.log('PLOT: ' + str(plot), level=log_level)
		#url = anchor.find(bytes("a")).text
		url = anchor.find('a')['href']#.text
		xbmc.log('URL: ' + str(url), level=log_level)
		#url = 'plugin://plugin.video.cflplus?mode=53&url=' + urllib_parse.quote_plus(gurl)
		#xbmc.log('URL: ' + str(url), level=log_level)
		#li = xbmcgui.ListItem(title)
		#li.setProperty('IsPlayable', 'true')
		#li.setInfo(type="Video", infoLabels={"mediatype":"video","title":title,"genre":"Sports"})
		#li.setArt({'thumb':artbase + 'cfl.jpg','fanart':defaultfanart})
		#xbmcplugin.addDirectoryItem(handle=pluginhandle, url=url, listitem=li, isFolder=False)
	#xbmcplugin.endOfDirectory(pluginhandle, cacheToDisc=True)
		#url = 'http://www.cfl.ca/videos/' + anchor.get('href')
		addDir(title, url, 53, artbase + 'cfl.jpg', artbase + 'defaultfanart.jpg', plot)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))


#53
def cfl_2016(url):
	br.set_handle_robots( False )
	response = br.open(url)
	xbmc.log('RESPONSE: ' + str(response.code), level=log_level)
	html = response.get_data()
	videoId = (re.compile('videoId=(.+?)&amp').findall(str(html))[0])
	xbmc.log('videoId: ' + str(videoId), level=log_level)
	#url = 'http://players.brightcove.net/4401740954001/default_default/index.html?videoId=' + str(videoId)
	url = 'https://edge.api.brightcove.com/playback/v1/accounts/4401740954001/videos/' + str(videoId)
	xbmc.log('URL: ' + str(url), level=log_level)
	br.set_handle_robots( False )
	#response = br.open(url)
	res = requests.get(url, headers={'Accept':'application/json;pk=BCpkADawqM0dhxjC63Ux5MXyiMyIYB1S1bvk0iorISSaD1jFgWDyiv-JAcvE6XduNdDYxMdk_NTQWn91IQI9NLPkXd5UIw3cv49pcyJ5eW9QT0CWTrclSFHBHqSSyJ_9Ysgzc2v-Mw0wxNmZ'})
	#response = get_html(url)
	#xbmc.log('RESPONSE: ' + str(response.code), level=log_level)
	#result = res.json()
	xbmc.log('RESPONSE: ' + str(res), level=log_level)
	#data = response.json()
	#data = json.loads(res)
	data = res.json()
	xbmc.log('JSON: ' + len(str(data)), level=log_level)
	m3u8 = data['sources'][0]['src']
	name = data['name']
	xbmc.log('M3U8: ' + str(m3u8), level=log_level)
	play(name,m3u8)
	xbmcplugin.endOfDirectory(pluginhandle, cacheToDisc=True)


#55
def get_stream(url):
	xbmc.log('URL: ' + str(url))
	br.set_handle_robots( False )
	response = br.open(url)
	xbmc.log(str(response.code))
	html = response.get_data()
	soup = BeautifulSoup(html,'html5lib').find_all("iframe",{"class":"brightcove-iframe"})[0]
	xbmc.log('SOUP: ' + str(soup))
	key = re.compile('videoId=(.+?)&amp;').findall(str(soup))[0]
	xbmc.log('KEY: '  + str(key))
	stream = 'http://c.brightcove.com/services/mobile/streaming/index/master.m3u8?videoId=' + key + '&pubId=4401740954001'
	xbmc.log('STREAM: ' + str(stream))
	PLAY(stream)
	xbmcplugin.endOfDirectory(pluginhandle, cacheToDisc=True)


#99
def PLAY(url):
	listitem = xbmcgui.ListItem(path=url)
	xbmc.log('### SETRESOLVEDURL ###')
	listitem.setProperty('IsPlayable', 'true')
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
	xbmc.log('URL: ' + str(url), level=xbmc.LOGDEBUG)
	xbmcplugin.endOfDirectory(pluginhandle)


def get_sec(duration):
	l = duration.split(':')
	return int(l[0]) * 60 + int(l[1])


def play(name,url):
	xbmc.log('URL: ' + str(url), level=xbmc.LOGDEBUG)
	listitem = xbmcgui.ListItem(name)
	listitem.setArt({'thumb':artbase + 'cfl.jpg'})
	xbmc.Player().play( url, listitem )
	sys.exit("Stop Video")


def striphtml(data):
	p = re.compile(r'<.*?>')
	return p.sub('', data)


def add_directory2(name,url,mode,fanart,thumbnail,plot):
	u=sys.argv[0]+"?url="+urllib_parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib_parse.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=thumbnail)
	liz.setInfo( type="Video", infoLabels={ "Title": name,
											"plot": plot} )
	if not fanart:
		fanart=''
	liz.setProperty('fanart_image',fanart)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False, totalItems=10)
	return ok

def get_html(url):
	req = urllib.request.Request(url)
	req.add_header('Host','www.cfl.ca')
	req.add_header('User-Agent','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0')
	req.add_header('Accept', 'application/json;pk=BCpkADawqM0dhxjC63Ux5MXyiMyIYB1S1bvk0iorISSaD1jFgWDyiv-JAcvE6XduNdDYxMdk_NTQWn91IQI9NLPkXd5UIw3cv49pcyJ5eW9QT0CWTrclSFHBHqSSyJ_9Ysgzc2v-Mw0wxNmZ')

	try:
		response = urllib.request.urlopen(req)
		html = response.read()
		response.close()
	except urllib.error.HTTPError:
		response = False
		html = False
	return html




def get_params():
	param = []
	paramstring = sys.argv[2]
	if len(paramstring) >= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?', '')
		if (params[len(params) - 1] == '/'):
			params = params[0:len(params) - 2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0]] = splitparams[1]

	return param


def addDir(name, url, mode, thumbnail, fanart, infoLabels=True):
	u = sys.argv[0] + "?url=" + urllib.parse.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.parse.quote_plus(name)
	ok = True
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type="Video", infoLabels={"Title": name})
	liz.setArt({'thumb':thumbnail,'fanart':fanart})
	liz.setProperty('IsPlayable', 'true')
	if not fanart:
		fanart=defaultfanart
	liz.setProperty('fanart_image',fanart)
	ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
	return ok



def unescape(s):
	p = htmllib.HTMLParser(None)
	p.save_bgn()
	p.feed(s)
	return p.save_end()




params = get_params()
url = None
name = None
mode = None
cookie = None

try:
	url = urllib.parse.unquote_plus(params["url"])
except:
	pass
try:
	name = urllib.parse.unquote_plus(params["name"])
except:
	pass
try:
	edata = urllib.parse.unquote_plus(params["edata"])
except:
	pass
try:
	mode = int(params["mode"])
except:
	pass

xbmc.log("Mode: " + str(mode), level=log_level)
xbmc.log("URL: " + str(url), level=log_level)
xbmc.log("Name: " + str(name), level=log_level)

if mode == None or url == None or len(url) < 1:
	xbmc.log("Generate Main Menu", level=log_level)
	cfl(baseurl)
elif mode == 1:
	xbmc.log("Indexing Videos", level=log_level)
	INDEX(url)
elif mode == 99:
	play(name,url)
	xbmc.log("Play Video", level=log_level)
elif mode == 10:
	xbmc.log("Get CFL Stream", level=log_level)
	stream(url)
elif mode == 53:
	xbmc.log("CFL 2016", level=log_level)
	cfl_2016(url)
elif mode == 55:
	xbmc.log("CFL Get Stream", level=log_level)
	get_stream(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
