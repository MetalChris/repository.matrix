#!/usr/bin/python
#
#
# Written by MetalChris 09.02.2026
# Released under GPL(v2 or later)

from six.moves import urllib_parse
from kodi_six import xbmc, xbmcplugin, xbmcaddon, xbmcgui, xbmcvfs
import urllib, re, sys, os
import bs4
from bs4 import BeautifulSoup
import mechanicalsoup
import requests
import time

kickoff = 1781985617
PRE_ROLL = 1800  # 30 minutes


if sys.version_info >= (3, 4, 0):
	import html
	_html_parser = html
	PY2 = False
	translatePath = xbmcvfs.translatePath
else:
	from six.moves import html_parser
	_html_parser = html_parser.HTMLParser()
	PY2 = True
	translatePath = xbmc.translatePath

artbase = 'special://home/addons/plugin.video.cflplus/resources/media/'
_addon = xbmcaddon.Addon()
_addon_path = _addon.getAddonInfo('path')
selfAddon = xbmcaddon.Addon(id='plugin.video.cflplus')
translation = selfAddon.getLocalizedString
usexbmc = selfAddon.getSetting('watchinxbmc')
settings = xbmcaddon.Addon(id="plugin.video.cflplus")
addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')
__resource__   = xbmcvfs.translatePath( os.path.join( _addon_path, 'resources', 'lib'))

sys.path.append(__resource__)

from uas import *

log_notice = settings.getSetting(id="log_notice")
if log_notice != 'false':
	log_level = xbmc.LOGNOTICE if PY2 else xbmc.LOGINFO
else:
	log_level = xbmc.LOGDEBUG
xbmc.log('LOG_NOTICE: ' + str(log_notice), level=log_level)
xbmc.log(('CFL+ 05.16.2024 - 2024.05.25'),level=log_level)

#quality = settings.getSetting(id="quality")
#xbmc.log('QUALITY: ' + str(quality), level=log_level)


plugin = "CFL Video"

defaultimage = 'special://home/addons/plugin.video.cflplus/resources/media/icon.png'
defaultfanart = 'special://home/addons/plugin.video.cflplus/resources/media/fanart.jpg'
defaulticon = 'special://home/addons/plugin.video.cflplus/resources/media/icon.png'
pubId = '4401740954001'

local_string = xbmcaddon.Addon(id='plugin.video.cflplus').getLocalizedString
pluginhandle = int(sys.argv[1])
confluence_views = [500,501,502,503,504,508,515]
baseurl = 'https://www.cfl.ca/plus/'

browser = mechanicalsoup.Browser(soup_config={'features': 'html.parser'})
#browser.addheaders = [('Host', 'www.cfl.ca')]
#browser.addheaders = [('User-agent', ua)]
#browser.addheaders = [('Accept', 'application/json;pk=BCpkADawqM0dhxjC63Ux5MXyiMyIYB1S1bvk0iorISSaD1jFgWDyiv-JAcvE6XduNdDYxMdk_NTQWn91IQI9NLPkXd5UIw3cv49pcyJ5eW9QT0CWTrclSFHBHqSSyJ_9Ysgzc2v-Mw0wxNmZ')]

browser.session.headers.update({
	'Referer': 'https://cfl.ca/',
    'User-Agent': ua,
    'Accept': 'application/json;pk=BCpkADawqM0dhxjC63Ux5MXyiMyIYB1S1bvk0iorISSaD1jFgWDyiv-JAcvE6XduNdDYxMdk_NTQWn91IQI9NLPkXd5UIw3cv49pcyJ5eW9QT0CWTrclSFHBHqSSyJ_9Ysgzc2v-Mw0wxNmZ'
    # Add any other headers you need
})

xbmc.log('UA: ' + str(ua))


def cfl(baseurl):
	#browser.set_handle_robots( False )
	response = browser.get('https://www.cfl.ca/plus/')
	html = response.text
	xbmc.log('RESPONSE: ' + str(response.status_code), level=log_level)
	#xbmc.log('RESPONSE TEXT: ' + str(html), level=log_level)
	soup = BeautifulSoup(html, 'html.parser')
	#soup = response.soup
	for anchor in soup.find_all("div", {"class":"relative z-10 flex w-full flex-col lg:container lg:flex-row lg:py-12 gap-2 lg:gap-5"}):
		if not anchor.find('div', {'class':'lg:max-w-138.5'}):
			continue
		#xbmc.log('ANCHOR: ' + str(anchor), level=log_level)
		#title = anchor.find("div",{"class":"lg:max-w-138.5"}).text.strip()
		title = anchor.find("h1").text.strip()
		xbmc.log('TITLE: ' + str(title), level=log_level)
		plot = anchor.find("p",{"class":"typography-lg-light"}).text.strip()
		#img = anchor.find("div",{"class":"item-image"})#.text.strip()
		image = anchor.find("img")["src"]#.text.strip()
		xbmc.log('IMAGE: ' + str(image), level=log_level)
		if image is None:
			image = defaulticon
			#xbmc.log('IMAGE: ' + str(image), level=log_level)
		#else:
			#image = (re.compile("\'(.+?)\'").findall(str(img))[0])
			#xbmc.log('IMAGE: ' + str(image), level=log_level)
		xbmc.log('ANCHOR: ' + str(anchor)[:100], level=log_level)
		game_url = 'https://cfl.ca' + re.compile('href="(.+?)"').findall(str(anchor))[0]
		xbmc.log('URL: ' + str(game_url), level=log_level)
		#plot = get_plot(game_url)
		xbmc.log('PLOT: ' + str(plot), level=log_level)
		url = 'plugin://plugin.video.cflplus?mode=53&url=' + urllib_parse.quote_plus(game_url)
		xbmc.log('URL: ' + str(url), level=log_level)
		li = xbmcgui.ListItem(title)
		li.setProperty('IsPlayable', 'true')
		xbmcplugin.setContent(pluginhandle, 'episodes')
		li.setInfo(type="Video", infoLabels={"mediatype":"video","title":title,"genre":"Sports","plot":plot})
		li.setArt({'thumb':image,'fanart':artbase + 'fanart.jpg'})
		xbmcplugin.addDirectoryItem(handle=pluginhandle, url=url, listitem=li, isFolder=False)
	xbmcplugin.endOfDirectory(pluginhandle, cacheToDisc=True)


#53
def get_stream(url):
	#browser.set_handle_robots( False )
	response = browser.get(url)
	xbmc.log('RESPONSE: ' + str(response.status_code), level=log_level)
	html = response.text
	videoId = (re.compile('videoId=(.+?)",').findall(str(html))[0])
	xbmc.log('videoId: ' + str(videoId), level=log_level)
	url = 'https://edge.api.brightcove.com/playback/v1/accounts/4401740954001/videos/' + str(videoId)
	xbmc.log('URL: ' + str(url), level=log_level)
	#browser.set_handle_robots( False )
	res = requests.get(url, headers={'Accept':'application/json;pk=BCpkADawqM0dhxjC63Ux5MXyiMyIYB1S1bvk0iorISSaD1jFgWDyiv-JAcvE6XduNdDYxMdk_NTQWn91IQI9NLPkXd5UIw3cv49pcyJ5eW9QT0CWTrclSFHBHqSSyJ_9Ysgzc2v-Mw0wxNmZ'})
	#xbmc.log('STREAM RESPONSE: ' + str(res.text), level=log_level)
	data = res.json()
	xbmc.log('JSON: ' + str(len(data)), level=log_level)
	#xbmc.log('JSON: ' + str(data), level=log_level)
	if 'sources' in str(res.text):
		m3u8 = (data['sources'][0]['src'])
		offset = get_ts(m3u8)
		xbmc.log('OFFSET: ' + str(offset), level=log_level)
		#if quality != '4':
			#m3u8 = (data['sources'][0]['src']).replace('playlist.m3u8', 'profile_' + str(quality) + '/chunklist.m3u8')
		xbmc.log('M3U8: ' + str(m3u8), level=log_level)
		
		PLAY(m3u8, offset)
		xbmcplugin.endOfDirectory(pluginhandle, cacheToDisc=True)
	else:
		xbmc.log(('ACCESS_DENIED'), level=log_level)
		xbmcgui.Dialog().ok(addonname, 'This game is not available in your area.')
		xbmcplugin.endOfDirectory(pluginhandle, cacheToDisc=True)
		
		
def get_ts(m3u8):	
	xbmc.log(('GET_TS'), level=log_level)
	from urllib.parse import urljoin

	playlist = requests.get(m3u8, headers={'User-Agent': ua}).text

	chunklist = None

	for line in playlist.splitlines():
		line = line.strip()
		if line.startswith('chunklist-dvr_hls1080p'):
			chunklist = urljoin(m3u8, line)
			break

	xbmc.log('CHUNKLIST: ' + str(chunklist), level=log_level)

	if chunklist:
		res = requests.get(chunklist, headers={'User-Agent': ua})
		chunk_data = res.text

		first_program_time = None
		last_program_time = None

		for line in chunk_data.splitlines():
			line = line.strip()

			if line.startswith('#EXT-X-PROGRAM-DATE-TIME:'):
				program_time = line.split(':', 1)[1]

				if first_program_time is None:
					first_program_time = program_time

				last_program_time = program_time

		xbmc.log('FIRST PROGRAM TIME: ' + str(first_program_time), level=log_level)
		xbmc.log('LAST PROGRAM TIME: ' + str(last_program_time), level=log_level)
				
		import time
		import calendar

		first_program_epoch = calendar.timegm(
			time.strptime(first_program_time.replace('Z', '').split('.')[0], '%Y-%m-%dT%H:%M:%S')
		)

		last_program_epoch = calendar.timegm(
			time.strptime(last_program_time.replace('Z', '').split('.')[0], '%Y-%m-%dT%H:%M:%S')
		)

		current_epoch = time.time()

		if current_epoch - last_program_epoch <= 30:
			offset = last_program_epoch - first_program_epoch
		else:
			offset = 0

		xbmc.log('FIRST PROGRAM EPOCH: ' + str(first_program_epoch), level=log_level)
		xbmc.log('LAST PROGRAM EPOCH: ' + str(last_program_epoch), level=log_level)
		xbmc.log('CALCULATED OFFSET: ' + str(offset), level=log_level)

		return offset

#99
def PLAY(url, offset):
	xbmc.log('OFFSET: ' + str(offset), level=log_level)
	listitem = xbmcgui.ListItem(path=url)
	#xbmc.log('### SETRESOLVEDURL ###', level=log_level)
	listitem.setProperty('IsPlayable', 'true')
	listitem.setProperty('inputstream', 'inputstream.adaptive')
	listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
	listitem.setProperty('inputstream.adaptive.stream_headers', f"User-Agent={ua}")
	listitem.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
	listitem.setMimeType('application/vnd.apple.mpegurl')
	listitem.setContentLookup(False)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)

	xbmc.sleep(1000)

	player = xbmc.Player()

	for i in range(50):
		if player.isPlaying() and player.getTotalTime() > 0:
			break
		xbmc.sleep(100)

	if player.isPlaying() and player.getTotalTime() > 0:
		xbmc.log(f"CFL offset = {offset}", xbmc.LOGINFO)
		xbmc.log(f"CFL player time = {player.getTime()}", xbmc.LOGINFO)
		xbmc.log(f"CFL player total = {player.getTotalTime()}", xbmc.LOGINFO)
		player.seekTime(offset)
	
	xbmc.log('URL: ' + str(url), level=log_level)
	xbmcplugin.endOfDirectory(pluginhandle)
	
	
def get_plot(url):
	response = browser.get(url)
	xbmc.log('RESPONSE: ' + str(response.status_code), level=log_level)
	html = response.text	
	plot = re.compile('description":"(.+?)",').findall(str(html))[0]
	return plot


def striphtml(data):
	p = re.compile(r'<.*?>')
	return p.sub('', data)


def get_html(url):
	req = urllib.request.Request(url)
	req.add_header('Host','www.cfl.ca')
	req.add_header('User-Agent','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0')
	req.add_header('Accept', 'application/json;pk=BCpkADawqM0dhxjC63Ux5MXyiMyIYB1S1bvk0iorISSaD1jFgWDyiv-JAcvE6XduNdDYxMdk_NTQWn91IQI9NLPkXd5UIw3cv49pcyJ5eW9QT0CWTrclSFHBHqSSyJ_9Ysgzc2v-Mw0wxNmZ')

	try:
		response = urllib.request.urlopen(req)
		html = response.read()
		response.close()
	except urllib.error.HTTPError:
		response = False
		html = False
	return html


def get_params():
	param = []
	paramstring = sys.argv[2]
	if len(paramstring) >= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?', '')
		if (params[len(params) - 1] == '/'):
			params = params[0:len(params) - 2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0]] = splitparams[1]

	return param
	


params = get_params()
url = None
name = None
mode = None
cookie = None

try:
	url = urllib.parse.unquote_plus(params["url"])
except:
	pass
try:
	name = urllib.parse.unquote_plus(params["name"])
except:
	pass
try:
	edata = urllib.parse.unquote_plus(params["edata"])
except:
	pass
try:
	mode = int(params["mode"])
except:
	pass

xbmc.log("Mode: " + str(mode), level=log_level)
xbmc.log("URL: " + str(url), level=log_level)
xbmc.log("Name: " + str(name), level=log_level)

if mode == None or url == None or len(url) < 1:
	xbmc.log("Generate Main Menu", level=log_level)
	cfl(baseurl)
elif mode == 99:
	play(name,url)
	xbmc.log("Play Video", level=log_level)
elif mode == 53:
	xbmc.log("CFL Get Stream", level=log_level)
	get_stream(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
